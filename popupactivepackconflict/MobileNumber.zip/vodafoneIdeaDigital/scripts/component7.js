$(document).ready(function(){
    placeholderLabel();
    $("#mobile").focus();
            $("#mobile").on("input", function() {
                    var reg = /^[01234]+/gi;
                    if (this.value.match(reg)) {
                            this.value = this.value.replace(reg, '');
                    }
            });
            
            $("#mobile").on("keyup input", function(event) {
                $(".crossImg").show();
                
                $(this).parent().removeClass("invalidBorder");
                var tempVal = $(this).val();
                this.value = this.value.replace(/[^0-9]/g, '');
            
                if (tempVal.length == 10 && (!isNaN(tempVal)) && event.type === "input") {
                    $("#amount").prop('disabled', false);
                    $(this).siblings(".invalid-feedback").hide();
                    $(this).parent().addClass("validBorder");
                    $("#ir-proceed").focus();
                } else if (tempVal.length > 10) {
                    
                } else if (tempVal.length > 0 && tempVal.length < 10 && (event.keyCode == 8 || event.keyCode == 46)) {
                    $(this).siblings(".invalid-feedback").show();
                    $(this).parent().addClass("invalidBorder");
                    $(this).parent().removeClass("validBorder");
                    $(".warning").show();
                    $(".clearAll").hide();
                } else if (tempVal.length > 0 && tempVal.length < 10) {
                    $(this).parent().addClass("validBorder");
                    $(this).siblings(".invalid-feedback").hide();
                   
                    $(".clearAll").show();
                    $(".warning").hide();
                } 
                if (tempVal.length == 0) {
                    $(this).siblings(".invalid-feedback").hide();
                    $(this).parent().removeClass("invalidBorder validBorder");
                    $(".clearAll, .warning").hide();
                }
            });
            function placeholderLabel() {
                $(".bootLabel").hide();
                var ua = window.navigator.userAgent;
                var msie = ua.indexOf("MSIE ");
        
                if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
                {
                    $(".form-control").focus(function(event) {
                        $(this).siblings(".bootLabel").show();
                    });
                    $(".form-control").on("blur", function(event) {
                        if (this.value.length == 0) {
                            $(this).siblings(".bootLabel").hide();
                        }
                    });
                } 
                else  // If another browser, return 0
                {
                    $(".form-control").on("keyup input", function(event) {
                        $(this).siblings(".bootLabel").show();
                        var tempVal = $(this).val();
                        if (tempVal.length <= 0){
                            $(this).siblings(".bootLabel").hide();
                        }
        
                    });
                }
        
                return false;
            }
         
            });
